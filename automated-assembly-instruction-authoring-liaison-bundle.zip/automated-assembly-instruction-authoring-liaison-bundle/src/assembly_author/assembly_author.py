import logging
import logging.config
from pathlib import Path

import yaml
from models import Part, PartOfSubassembly, Subassembly
from steputils import p21
from typedb.client import *

logger = logging.getLogger(__name__)

# loads logging configuration from yaml file
log_cfg_file = Path(__file__).with_name("logger.yaml")
with log_cfg_file.open("r") as f:
    log_cfg = yaml.safe_load(f)

# set logging config
logging.config.dictConfig(log_cfg)

logger.info("Logging initialised")


class AssemblyAuthor:

    __version__: str = "0.0.1"

    def __init__(self, step_path: str, typedb_hostname: str, typedb_database: str):
        self.step_path = step_path
        self.typedb_hostname = typedb_hostname
        self.typedb_database = typedb_database

        self.step_file = self.load_step_file()
        self.step_header = self.step_file.header
        self.step_data = self.step_file.data[0]
        self.concepts = []

    def load_step_file(self):
        """Reads step file through steputils parser."""
        logging.info("Loading step file from: %s", self.step_path)
        step_file = p21.readfile(self.step_path)
        logging.info(
            "Step file loaded successfully. File name: %s",
            step_file.header.get("FILE_NAME").params[0],
        )
        return step_file

    def filter_instances_by_type(self, instance_type: str):
        """Filters step file instances according to a single entity type."""
        instance_filter = {
            k: v
            for k, v in self.step_data.instances.items()
            if self.catch(lambda: v.entity.name == instance_type)
        }
        return instance_filter

    def catch(self, func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except AttributeError:
            return

    def get_product_from_occurrence(self, occurrence, relation):
        """Navigates usage occurences in a step file and gets related products.

        Returns
        -------
        product : object
            steputils entity object of PRODUCT type
        """
        # gets reference for PRODUCT_DEFINITION
        product_def_ref = occurrence.entity.params[relation]
        # gets reference for PRODUCT_DEFINITION_FORMATION_WITH_SPECIFIED_SOURCE
        product_def_formation_ref = self.step_data.get(product_def_ref).entity.params[2]
        # gets reference for PRODUCT
        product_ref = self.step_data.get(product_def_formation_ref).entity.params[2]
        # gets product data
        product = self.step_data.get(product_ref)
        return product

    def get_assembly_struct(self):
        """Derives occurrences of component definitions as used in an immediate next higher parent assembly."""
        assembly_occurrences = self.filter_instances_by_type(
            "NEXT_ASSEMBLY_USAGE_OCCURRENCE"
        )

        for _, assembly_occurrence in assembly_occurrences.items():
            subassem_product = self.get_product_from_occurrence(assembly_occurrence, 3)
            subassem = self.product_to_subassembly(subassem_product)
            part_product = self.get_product_from_occurrence(assembly_occurrence, 4)
            part = self.product_to_part(part_product)
            subassem_relation = PartOfSubassembly(part=part, subassembly=subassem)
            self.concepts.extend([part, subassem, subassem_relation])

    def product_to_part(self, product):
        """Converts a step product instance to a part schema type."""
        part = Part(
            id=product.entity.params[0],
            name=product.entity.params[1],
            step_id=product.ref,
        )
        return part

    def product_to_subassembly(self, product):
        """Converts a step product instance to a part schema type."""
        subassembly = Subassembly(
            id=product.entity.params[0],
            name=product.entity.params[1],
            step_id=product.ref,
        )
        return subassembly

    def insert_concepts(self):
        """Uploads concepts to TypeDB knowledge graph."""
        with TypeDB.core_client(self.typedb_hostname) as client:
            with client.session(self.typedb_database, SessionType.DATA) as session:
                logging.info(
                    "Performing TypeDB inserts for %s concepts", len(self.concepts)
                )
                for concept in self.concepts:
                    with session.transaction(TransactionType.WRITE) as transaction:
                        transaction.query().insert(concept.insert_query())
                        transaction.commit()


step_path = "/home/jay/Documents/35587-GA-100-Motor.stp"

assembly_author = AssemblyAuthor(
    step_path=step_path, typedb_hostname="localhost:1729", typedb_database="AAIA"
)
assembly_author.get_assembly_struct()
assembly_author.insert_concepts()
