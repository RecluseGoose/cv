import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class Part:
    """Part entity"""

    id: str
    name: str
    step_id: str
    type: str = "part"
    thing_type: str = "entity"

    def insert_query(self):
        return f'insert $x isa {self.type}, has id "{self.id}", has name "{self.name}";'


@dataclass
class Subassembly:
    """Subassembly entity"""

    id: str
    name: str
    step_id: str
    type: str = "subassembly"
    thing_type: str = "entity"

    def insert_query(self):
        return f'insert $x isa {self.type}, has id "{self.id}", has name "{self.name}";'


@dataclass
class PartOfSubassembly:
    """Part of subassembly relationship"""

    part: Part
    subassembly: Subassembly
    type: str = "partOfSubassembly"
    thing_type: str = "relation"

    def insert_query(self):
        return f'match $part isa {self.part.type}, has id "{self.part.id}"; $subassembly isa {self.subassembly.type}, has id "{self.subassembly.id}"; insert $relation (part: $part, subassembly: $subassembly) isa {self.type};'
