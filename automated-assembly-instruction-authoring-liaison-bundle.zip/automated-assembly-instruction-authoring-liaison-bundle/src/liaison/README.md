## Using this code 
The FreeCAD script can be used to generate entity tree file (pickle format) with the following command

```
/usr/lib/freecad/bin/freecadcmd-python3 freecad_script.py <path to step file>
```

Once complete, a 'touch' graph can be generated using the following (this may take a while)

```
python -im liaison_grapher <path to step file>

note: the -im option enters you into interactive mode once the code is complete
```
