import os
import pickle

import FreeCAD as App  # FreeCAD library
import Import  # FreeCAD library
import Part  # FreeCAD library
from part_entity_type import PartFeatureEntity, toNumpy  # Local library


def isAppPart(entity):
    # Fugly function for weird 'App.Part' / 'Part' workaround
    # ... for some reason App.Part is illusive (class appears to exists but can't access it via App.Part)
    # "App.Part" should be a class, but if you "from FreeCAD import Part", it's a module, the same as "import Part"
    # isinstance(entity, App.Part) <-- (this is what I'd like to use)
    return "App.Part" in str(entity.__class__)


class PartFeatureLookup(object):
    def __init__(self, fn):
        """Class for extracting entity tree and transformation matrices from file fn"""
        # import file into Freecad Applicaiton
        assert fn.split(".")[-1].lower() in [
            "stp",
            "step",
        ], "must be step file: {}".format(fn)
        assert os.path.isfile(fn), "file not found: {}".format(fn)
        Import.insert(fn, "")
        # populate the various bits...
        self.allLabels = set()
        self.allPartEntities = {}
        self.tree = self.pullAllFromActiveDoc()
        self.matrices = self.getMatrices()

    def pullAllFromActiveDoc(self):
        """Gets active document and populates entity tree"""
        active = App.ActiveDocument.ActiveObject.InListRecursive
        ents = [
            self.pullTree(entity)
            for entity in active
            if isAppPart(entity) or isinstance(entity, Part.Feature)
        ]
        tree = self._condenseDictList(ents)
        self.allLabels.update(tree.keys())
        return tree

    def _condenseDictList(self, dl):
        """
        Helper function to condense list of dictionaries into one
        dictionary
        """
        bDict = {}
        [bDict.update(_) for _ in dl]
        return bDict

    def pullTree(self, entity):
        """
        recursive function that extracts tree of Part.Feature
        instances
        """
        if isAppPart(entity):
            branch = []
            for subEntity in entity.OutList:
                retval = self.pullTree(subEntity)
                if retval is not None:
                    branch.append(retval)
            self.allLabels.add(entity.Label)
            return {entity.Label: self._condenseDictList(branch)}

        elif isinstance(entity, Part.Feature):
            self.allLabels.add(entity.Label)
            self.allPartEntities[entity.Label] = PartFeatureEntity(entity)
            return {entity.Label: None}

    def getMatrices(self, labels=None):
        """
        pulls transformation matrices for each entity
        """
        labels = labels or self.allLabels
        matrices = {}
        for lab in labels:
            matObj = App.ActiveDocument.getObjectsByLabel(lab)[0].Placement.toMatrix()
            matrices[lab] = toNumpy(matObj)
        return matrices

    def save(self, fn="outfile.pkl"):
        contents = {
            "tree": self.tree,
            "matrices": self.matrices,
            "labels": self.allLabels,
            "entities": self.allPartEntities,
        }
        with open(fn, "wb") as f:
            f.write(pickle.dumps(contents))
