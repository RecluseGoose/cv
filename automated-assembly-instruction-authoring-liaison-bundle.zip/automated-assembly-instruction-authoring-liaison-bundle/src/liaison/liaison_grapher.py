import os
import pickle
import subprocess
import sys
from time import time as time

import cadquery as cq

# import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from freecad_process_outfile import processFreeCadTree
from progress_bar import percentComplete

FREECAD_PYTHON_PATH = "/usr/lib/freecad/bin/freecadcmd-python3"


class LiaisonGrapher(object):
    """
    Class for liaison graphing

    Expected useage
    >>> lg = LiaisonGrapher("myStepFile.stp")

    Then
    >>> M = lg.makeMatrix()
    and / or
    >>> G = lg.makeGraph()
    """

    def __init__(self, stepFilePath):
        self.stepFilePath = stepFilePath
        self.matrix = None
        self.partNames = []
        self.matrixCreated = False
        self.cacheFilename = self._getCacheFilename(stepFilePath)

    def _getCacheFilename(self, stepFilePath):
        """
        Standardises naming conventions for cache filenames.

        Cache files will go here:
        /tmp/liaison            [linux]
        /%USERPROFILE%/liaison  [windows]
        """
        bareFilename = os.path.split(stepFilePath)[-1]
        pklFilename = ".".join(bareFilename.split(".")[:-1] + ["pkl"])
        if "linux" in sys.platform.lower():
            cachedir = "/tmp/liaison"
        else:
            cachedir = "%USERPROFILE%/liaison"
        if not os.path.isdir(cachedir):
            os.mkdir(cachedir)
        return os.path.join(cachedir, pklFilename)

    def writeCache(self):
        """Write the cache file"""
        contents = {"matrix": self.matrix, "partNames": self.partNames}
        with open(self.cacheFilename, "wb") as f:
            f.write(pickle.dumps(contents))

    def readCache(self):
        """Load results from the cache file"""
        if os.path.isfile(self.cacheFilename):
            print("Reading cache")
            with open(self.cacheFilename, "rb") as f:
                contents = pickle.load(f)
            self.matrix = contents["matrix"]
            self.partNames = contents["partNames"]
            self.matrixCreated = True
            return True
        else:
            return False

    def clearCache(self):
        """Delete the cache file"""
        if os.path.isfile(self.cacheFilename):
            os.remove(self.cacheFilename)

    def _runFreeCAD(self, inputFile, outputFile):
        """Run freecad script to produce tempfile for naming"""
        assert os.path.isfile(inputFile), "File not found: {}".format(inputFile)
        # return os.system(' '.join([FREECAD_PYTHON_PATH, 'freecad_script.py', inputFile, outputFile]))
        process = subprocess.Popen(
            [FREECAD_PYTHON_PATH, "freecad_script.py", inputFile, outputFile],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, stderr = process.communicate()
        stdout, stderr
        return stdout, stderr

    def _isInside(self, bb0, bb1):
        """
        checks if bb1 is inside bb0
        cadquery already has this but it's slow af for some reason
        """
        thresh = 0.05
        for x, y, z in [[bb1.xmin, bb1.ymin, bb1.zmin], [bb1.xmax, bb1.ymax, bb1.zmax]]:
            if (
                (x - thresh) < bb1.xmax
                and (x + thresh) > bb1.xmin
                and (y - thresh) < bb1.ymax
                and (y + thresh) > bb1.ymin
                and (z - thresh) < bb1.zmax
                and (z + thresh) > bb1.zmin
            ):
                return True
            else:
                continue
        return False

    def _areLiaisons(self, p0, p1):
        """Check whether parts p0 and p1 liaise with eachother

        Parts are cadquery.shapes.Solid
        """
        bb0 = p0.BoundingBox()
        bb1 = p1.BoundingBox()
        bbCheck = self._isInside(bb0, bb1) or self._isInside(bb1, bb0)
        if bbCheck:
            touchThresh = 0.05
            areTouching = p0.distance(p1) < touchThresh
            return areTouching
        else:
            return False

    def makeMatrix(self):
        """Generate liaison matrix"""
        # check cache
        if self.readCache():
            return self.matrix
        # get temporary data from FreeCAD script
        tempfile = "./tempoutfile.pkl"
        self._runFreeCAD(self.stepFilePath, tempfile)
        # read data from FreeCAD script
        data, coms, vols, G = processFreeCadTree(tempfile)
        os.remove(tempfile)

        # Get all entities (shapes.Solid objects) with
        wp = cq.importers.importStep(self.stepFilePath)
        parts = []
        objs = list(wp.objects)
        while objs:
            thisItem = objs.pop()
            if not hasattr(thisItem, "isSolid"):
                if hasattr(thisItem, "__iter__"):
                    objs += list(thisItem)
                else:
                    continue
            else:
                parts.append(thisItem)
        self.parts = parts

        # Correlate centres and volumes to identify which component is which
        centers = np.array([p.Center().toTuple() for p in parts])
        volumes = np.array([p.Volume() for p in parts])
        cv = np.hstack((centers, volumes[:, None]))
        pairings = {}
        for entName in coms.keys():
            c = coms[entName]
            v = vols[entName]
            diffs = cv - np.hstack((c, v))
            sorts = np.argsort(np.linalg.norm(diffs, axis=1))
            iMatch = sorts[0]
            if parts[iMatch].label == "":
                parts[iMatch].label = entName
                pairings[entName] = iMatch
            else:
                # an issue has occurred. most likely the code has found duplated parts
                print("Encountering auto labelling issues: {}".format(entName))

        # Get combinations to test to populate upper triangular matrix
        nParts = len(parts)
        touchMatrix = np.zeros((nParts, nParts), dtype=bool)
        triUpper = np.triu(np.ones((nParts, nParts), dtype=bool), 1)
        ijToCalc = list(zip(*np.where(triUpper)))
        print("{} part pairings to test for {} parts".format(len(ijToCalc), nParts))

        tstart = time()
        # Chug through and populate matrix
        for i_calc, (i, j) in enumerate(ijToCalc[:]):
            p0, p1 = parts[i], parts[j]
            if self._areLiaisons(p0, p1):
                touchMatrix[j, i] = True
                touchMatrix[i, j] = True
            percentComplete(i_calc, len(ijToCalc))
        print("\n")
        self.matrixCreated = True
        self.matrix = touchMatrix
        self.partNames = [p.label for p in parts]
        tend = time()
        print("Completed {} checks in {:1.2f}s".format(len(ijToCalc), tend - tstart))
        self.writeCache()
        return touchMatrix

    def makeGraph(self):
        """Generate liaison graph"""
        # make liaison matrix
        if not self.matrixCreated:
            self.makeMatrix()
        # convert matrix to graph
        G = nx.Graph()
        [G.add_node(name) for name in self.partNames]
        triUpper = np.triu(self.matrix, 1)
        ijToCalc = list(zip(*np.where(triUpper)))

        for i_calc, (i, j) in enumerate(ijToCalc[:]):
            G.add_edge(self.partNames[i], self.partNames[j])
        return G


if __name__ == "__main__":
    lg = LiaisonGrapher(sys.argv[-1])
    G = lg.makeGraph()
