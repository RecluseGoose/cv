# This must be in a separate file to pickle / unpickle correctly.

import numpy as np


def toNumpy(m, outShape=None):
    n = len(m.A)
    if n == 16:
        outShape = (4, 4)
    return np.array(m.A).reshape(outShape)


class PartFeatureEntity(object):
    def __init__(self, partFeature):
        self.label = str(partFeature.Label)
        bb = self.bbToNumpy(partFeature.Shape.BoundBox)
        self.bb0, self.bb1 = np.vstack((bb, np.ones((2)))).T
        if hasattr(partFeature.Shape, "CenterOfMass"):  # can use shape directly
            self.vol = partFeature.Shape.Volume
            self.com = self.comToNumpy(partFeature.Shape.CenterOfMass)
        else:
            try:  # shape is a compound shape of .Solids
                compound = partFeature.Shape
                self.vol = np.sum([s.Volume for s in compound.Solids])
                com3 = (
                    np.mean([s.Volume * s.CenterOfMass for s in compound.Solids], 0)
                    / self.vol
                )
                self.com = self.comToNumpy(com3)
            except AttributeError:  # if all else fails...
                self.vol = np.nan
                self.com = np.nan * np.ones(4)

    def bbToNumpy(self, bbObj):
        bb = (bbObj.XMin, bbObj.XMax, bbObj.YMin, bbObj.YMax, bbObj.ZMin, bbObj.ZMax)
        return np.array(bb).reshape(3, 2)

    def comToNumpy(self, com):
        return np.array([com.x, com.y, com.z, 1.0])

    def __repr__(self):
        return "Part.Feature: <" + self.label + ">"
