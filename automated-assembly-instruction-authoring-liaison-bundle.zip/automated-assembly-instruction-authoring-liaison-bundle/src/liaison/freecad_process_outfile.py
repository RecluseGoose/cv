import pickle

import networkx as nx
import numpy as np


def loadPickle(fn):
    """Pull data from a pickle file"""
    with open(fn, "rb") as f:
        data = pickle.load(f)
    return data


def treeToGraph(tree):
    """Converts a nested tree of dictionaries to a networkx graph"""
    # stolen from here:
    # https://stackoverflow.com/questions/43081273/

    # Empty directed graph
    G = nx.DiGraph()

    # Iterate through the slayers
    q = list(tree.items())
    while q:
        v, d = q.pop()
        for nv, nd in d.items():
            G.add_edge(v, nv)
            if isinstance(nd, dict):
                q.append((nv, nd))

    return G


def transformPositionData(data, G, targetPart):
    """
    Code for converting relative FreeCAD entity tree positions into absolute coords
    """

    rootPart = list(data["tree"].keys())[0]
    sequence = nx.shortest_path(G, source=rootPart, target=targetPart)[::-1]
    # skip first transform (it's a centre of BB transform, as far as I can tell)
    sequence = sequence[1:]
    vectors = [
        data["entities"][targetPart].com,
        data["entities"][targetPart].bb0,
        data["entities"][targetPart].bb1,
    ]

    outVecs = []
    for v in vectors:
        outVec = v.copy()
        for s in sequence:
            m = data["matrices"][s]
            outVec = np.matmul(m, outVec)
        outVecs.append(outVec)

    # note that bounding boxes will be useless after rotation...
    com, bb0, bb1 = outVecs
    bb = np.vstack((bb0, bb1))
    return np.vstack([com, bb.min(0), bb.max(0)])


def processFreeCadTree(filename="outfile.pkl"):
    """Top-level function for pulling required data from saved file"""
    # pull all data saved from PartFeatureLookup.save function
    data = loadPickle(filename)
    # Make a graph
    G = treeToGraph(data["tree"])
    # export centres of mass and volumes
    coms = {
        e: transformPositionData(data, G, e)[0][:3] for e in data["entities"].keys()
    }
    vols = {e: v.vol for e, v in data["entities"].items()}
    return data, coms, vols, G
