# intended useage is to run this code via the following command (FreeCAD 0.18.4)
# /usr/lib/freecad/bin/freecadcmd-python3 freecad_script.py model.stp

import os

# must append cwd to path for local imports to work
import sys

sys.path.append(os.getcwd())

# imports should now work
from freecad_utilities import PartFeatureLookup

# pull filename from cmd argument
inputFile, outputFile = sys.argv[-2:]

# fn = u"/home/robert/git/fems3.stp"

pfl = PartFeatureLookup(inputFile)
pfl.save(outputFile)
