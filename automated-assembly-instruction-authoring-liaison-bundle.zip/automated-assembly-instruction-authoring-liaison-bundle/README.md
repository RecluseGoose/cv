# Automated Assembly Instruction Authoring
Module for generating assembly instructions from STEP files.


## Installation

Installation requires a Pipenv dependency, first ensure that Pipenv is installed:

    pip install pipenv

Clone the repository:

    git clone https://git.mtc.local/Jay.Taylor/automated-assembly-instruction-authoring.git
    cd automated-assembly-instruction-authoring

If installing for development:

    pipenv install --pre --dev
    pipenv run pre-commit install -t pre-commit

Else:

    pipenv install

## Usage

TODO