from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    install_requires=[
        "antlr4-python3-runtime==4.11.1",
        "grpcio==1.44.0; python_version >= '3.6'",
        "protobuf==3.20.1; python_version >= '3.7'",
        "pyparsing==3.0.9; python_full_version >= '3.6.8'",
        "six==1.16.0; python_version >= '2.7' and python_version not in '3.0, 3.1, 3.2, 3.3'",
        "steputils==0.1",
        "typedb-client==2.12.1",
        "typedb-protocol==2.12.0",
    ],
    name="assembly_author",
    version="0.0.1",
    author="The AAIA Team",
    author_email="informatics@the-mtc.org",
    description="Sytem for authoring assembly instruction from step files",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://git.mtc.local/Jay.Taylor/automated-assembly-instruction-authoring",
    project_urls={
        "Bug Tracker": "https://git.mtc.local/Jay.Taylor/automated-assembly-instruction-authoring/-/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
)
