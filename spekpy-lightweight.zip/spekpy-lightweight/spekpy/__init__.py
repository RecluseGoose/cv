__version__ = '2.0.10'
from .SpekPy import Spek


